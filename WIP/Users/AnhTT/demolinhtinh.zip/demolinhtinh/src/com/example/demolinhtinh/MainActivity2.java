package com.example.demolinhtinh;

import android.support.v7.app.ActionBarActivity;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_activity2);
		
	}
	
	public void checkLogin(View v){
		EditText etPhone = (EditText) findViewById(R.id.et_phonenumber);
		EditText etPass = (EditText) findViewById(R.id.et_password);
		
		String phone = etPhone.getText().toString();
		String pass = etPass.getText().toString();
		if(phone.equals("01666116617") && pass.equals("admin")){
            //Toast.makeText(getApplicationContext(),"Login Successful!",Toast.LENGTH_LONG).show();
            //Log.i("TEST","OK");
			Builder dialog = new AlertDialog.Builder(MainActivity2.this);
			dialog.setTitle("Login Successfully");
			//dialog.setMessage("Are you sure you want to delete this entry?");
			dialog.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
		        public void onClick(DialogInterface dialog, int which) { 
		            // continue with delete
		        	Intent intent = new Intent(MainActivity2.this,MainActivity2.class); //chuyen du lieu tu main 1 sang main 2
		            startActivity(intent);
		        }
		     });
			dialog.show();
        }else {
            Toast.makeText(getApplicationContext(),"Your phone number or Password error",Toast.LENGTH_LONG).show();
        }
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main_activity2, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void checkCancel(View v){
//		finishActivity();
		super.onBackPressed();
		
	}
}
