package com.example.trantuanh.myapplication1234;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void checkLogin (View v) {
        EditText email = (EditText) findViewById(R.id.et_email);
        EditText password = (EditText) findViewById(R.id.et_password);
        // chuy?n XML th�nh code
        String mEmail = email.getText().toString();
        String mPassword = password.getText().toString();
        // l?y d? li?u t? email v� password
        Log.i("Test", mEmail);
        Log.i("Test", mPassword);
        if (mEmail.equals("abc") && mPassword.equals("abc")){
            Toast.makeText(this,"Login Successful",Toast.LENGTH_LONG).show();
            // Toast.length_long l� th?i gian hi?n tr�n m�n h?nh.
        }else if(mEmail.equals(null) || mEmail.equals("")) {
            Toast.makeText(this, "Please input your Email",Toast.LENGTH_LONG).show();
        }else if (mPassword.equals(null) || mPassword.equals("")){
            Toast.makeText(this, "Please input your Password", Toast.LENGTH_LONG).show();
        }else Toast.makeText(this, "Email or Password Incorrect", Toast.LENGTH_LONG).show();
    }
    public void checkSignup(View v){
        Intent intent = new Intent(this, SignupActivity.class);
        startActivity(intent); // chuyen sang signup xu li code
    }
    public void checkForgot(View v){
        Intent intent2 = new Intent(this, ForgotPasswordActivity.class);
        startActivity(intent2);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
