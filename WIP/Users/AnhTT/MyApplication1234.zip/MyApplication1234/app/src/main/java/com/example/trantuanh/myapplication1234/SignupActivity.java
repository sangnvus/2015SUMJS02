package com.example.trantuanh.myapplication1234;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class SignupActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }
    public void checkAccept(View v) {
        final EditText email = (EditText) findViewById(R.id.et_email);
        final EditText password = (EditText) findViewById(R.id.et_password);
        final EditText confirm = (EditText) findViewById(R.id.et_confirm);
        // chuy?n XML thành code
        String mEmail = email.getText().toString();
        String mPassword = password.getText().toString();
        String mConfirm = confirm.getText().toString();
        // l?y d? li?u t? email và password
        boolean check = true;
        if(mEmail.equals(null) || mEmail.equals("")){
            Toast.makeText(this, "Please input your email!",Toast.LENGTH_LONG).show();
            check = false;
        }else if(mPassword.equals(null) && mPassword.equals("")){
            Toast.makeText(this, "Please input your password!", Toast.LENGTH_LONG).show();
            check = false;
        }else if (mPassword.length() < 6){
            Toast.makeText(this, "Your password must >= 6 Character!", Toast.LENGTH_LONG).show();
            check = false;
        }else if(!mPassword.equals(mConfirm)  ){
            Toast.makeText(this, "Password does not match!", Toast.LENGTH_LONG).show();
            check = false;
        }
        Log.i("Test", mEmail);
        Log.i("Test", mPassword);
        Log.i("Test", mConfirm);
        Log.i("Test", String.valueOf(mPassword.length()));
        if(check == true){
            AlertDialog.Builder dialog = new AlertDialog.Builder(SignupActivity.this);
            dialog.setTitle("Signup successfully!");
            dialog.setMessage("Do you want to login now?");
            dialog.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    // continue with code
                    Intent intent = new Intent(SignupActivity.this, MainActivity.class); //chuyen du lieu tu main 1 sang main 2
                    startActivity(intent);
                }
            });
            dialog.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    // do nothing
                    email.setText(null);
                    password.setText(null);
                    confirm.setText(null);
                    dialog.cancel();
                }
            });
            dialog.setIcon(android.R.drawable.ic_dialog_alert);
            dialog.show();
        }

    }

    public void back (){
        super.onBackPressed();
    }

}
