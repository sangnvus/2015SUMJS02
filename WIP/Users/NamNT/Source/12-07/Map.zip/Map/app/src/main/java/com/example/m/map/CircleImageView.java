package com.example.m.map;

/**
 * Created by M on 7/9/2015.
 */
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ImageView;
/**
 * Private class created to work around issues with AnimationListeners being
 * called before the animation is actually complete and support shadows on older platforms.
 */
public class CircleImageView extends View {

    float radius, startAtX, startAtY;
    Paint paintCircle, paintText;
    float textSize;

    public CircleImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.CircleImageView, 0, 0);
        try {
            radius = a.getDimension(R.styleable.CircleImageView_radius, 100f);
            startAtX = a.getDimension(R.styleable.CircleImageView_startAtX, 0f);
            startAtY = a.getDimension(R.styleable.CircleImageView_startAtY, 0f);
            textSize = a.getFloat(R.styleable.CircleImageView_textSize, 170f);

        } finally {
            a.recycle();
        }
        paintCircle = new Paint();
        paintCircle.setColor(0xfffed325); //YELLOW


    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
                canvas.drawCircle(startAtX, startAtY, radius, paintCircle);

        paintText = new Paint();
        paintText.setColor(Color.RED);
        paintText.setTextSize(textSize);
//        paintText.setFakeBoldText(true);
        paintText.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paintText.setAntiAlias(true);
        paintText.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("01", startAtX-textSize/2, startAtY+textSize/13*5, paintText);
    }
}
