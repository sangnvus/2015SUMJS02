package com.example.m.map;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;

import java.lang.reflect.Array;
import java.util.ArrayList;


public class BusListActivity extends ActionBarActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_list);

        RecyclerView rv = (RecyclerView) findViewById(R.id.bus_list);

        rv.setHasFixedSize(true);

        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);

        ArrayList<String> data = new ArrayList<String>();
        data.add("Cầu Giấy - Bờ Hồ");
        data.add("Long Biên - Mỹ Đình");
        data.add("Văn Điển - Việt Đức");
        data.add("Giáp Bát - Nhổn");
        data.add("Đội Cấn - Hàng Bồ");
        data.add("Nguyễn Thiện Thuật - Lương Văn Can");
        data.add("Nguyễn Chí Thanh - Dương Quảng Hàm");
        data.add("Ngụy Như Kon Tum - Nguyễn Lương Bằng");


        RecyclerView.Adapter a;
        a = new BusListAdapter(data);
        rv.setAdapter(a);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_bus_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
