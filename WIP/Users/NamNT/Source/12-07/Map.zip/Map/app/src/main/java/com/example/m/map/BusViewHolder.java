package com.example.m.map;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

/**
 * Created by M on 7/10/2015.
 */
public class BusViewHolder extends RecyclerView.ViewHolder{
    public TextView icBusNumber, tvBusName;
//    public int busOrder;

    public BusViewHolder(View v){
        super(v);
        this.icBusNumber = (TextView) v.findViewById(R.id.bus_number);
        this.tvBusName = (TextView) v.findViewById(R.id.bus_name);
    }
}
