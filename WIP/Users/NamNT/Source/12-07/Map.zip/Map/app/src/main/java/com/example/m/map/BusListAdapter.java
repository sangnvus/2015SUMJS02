package com.example.m.map;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by M on 7/10/2015.
 */
public class BusListAdapter extends RecyclerView.Adapter<BusViewHolder> {
    private ArrayList<String> busList;

    // Provide a suitable constructor (depends on the kind of dataset)
    public BusListAdapter(ArrayList<String> data) {
        busList = data;
    }

    //Update data
    public void updateList(ArrayList<String> data) {
        busList = data;
        notifyDataSetChanged();
    }

    // Create new views (invoked by the layout manager)
    @Override
    public BusViewHolder onCreateViewHolder(ViewGroup parent,
                                                   int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.bus_item, parent, false);
        // set the view's size, margins, paddings and layout parameters

        return new BusViewHolder(v);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(BusViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        if(position<10){
            holder.icBusNumber.setText("0"+(position+1));
        } else{
            holder.icBusNumber.setText(""+(position+1));
        }
        holder.tvBusName.setText(busList.get(position));

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return busList.size();
    }

//    public void addItem(int position, Data data) {
//        mData.add(position, data);
//        notifyItemInserted(position);
//    }
//
//    public void removeItem(int position) {
//        mData.remove(position);
//        notifyItemRemoved(position);
//    }
}